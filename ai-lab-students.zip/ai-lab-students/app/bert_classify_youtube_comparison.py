from sklearn.exceptions import UndefinedMetricWarning
from llm_service import LLMService
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score
import warnings
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

# Suppress specific warnings
warnings.filterwarnings("ignore", category=UndefinedMetricWarning)

# Suppress specific warnings
warnings.filterwarnings("ignore", category=FutureWarning)

# Dependency injection of the LLM service
llm_service = LLMService(api_key="group4_vmnmu", api_url="https://llm-api.aieng.fim.uni-passau.de/v1/chat/completions")

# Load the CSV file into a DataFrame
df = pd.read_csv('youtoxic_english_1000.csv')

# Prepare lists to store true and predicted labels
true_labels = []
predicted_labels = []

# Iterate over the first 10 rows of the DataFrame
for index, row in df.head(10).iterrows():
    # Load the pre-trained tokenizer
    tokenizer = AutoTokenizer.from_pretrained("Hate-speech-CNERG/bert-base-uncased-hatexplain")

    # Load the pre-trained model with the specific argument to suppress the warning
    model = AutoModelForSequenceClassification.from_pretrained(
        "Hate-speech-CNERG/bert-base-uncased-hatexplain",
        attn_implementation="eager"
    )

    # Prepare the input text
    inputs = tokenizer(row['Text'], return_tensors="pt", padding=True, truncation=True)

    # Get predictions from the model
    with torch.no_grad():
        outputs = model(**inputs)

    # Get the predicted class
    logits = outputs.logits
    predicted_label = torch.argmax(logits, dim=1).item()
        
    # Determine the true label based on the row data
    if row['IsHatespeech'] or row['IsRacist'] or row['IsSexist'] or row['IsHomophobic'] or row['IsReligiousHate']:
        true_label = 0  # hate speech
    elif row['IsToxic'] or row['IsAbusive'] or row['IsObscene'] or row['IsThreat'] or row['IsProvocative']:
        true_label = 2  # offensive
    else:
        true_label = 1  # normal

    # Append the true and predicted labels to their respective lists
    true_labels.append(true_label)
    predicted_labels.append(predicted_label)

# Calculate accuracy, precision, and recall
accuracy = accuracy_score(true_labels, predicted_labels)
precision = precision_score(true_labels, predicted_labels, average='weighted')
recall = recall_score(true_labels, predicted_labels, average='weighted')

# Print the results
print(f'Accuracy: {accuracy:.4f}')
print(f'Precision: {precision:.4f}')
print(f'Recall: {recall:.4f}')


