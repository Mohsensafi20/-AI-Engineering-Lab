import unittest
from unittest.mock import patch, Mock
import requests
from app import app

class ClassifyTests(unittest.TestCase):
    def setUp(self):
        # Set up the Flask test client
        self.app = app.test_client()
        self.app.testing = True

    @patch('requests.post')
    def test_classify_success(self, mock_post):
        # Mock the API response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'choices': [{'message': {'content': 'Hello! I\'m here to help.'}}]
        }
        mock_post.return_value = mock_response

        # Make a POST request to the classify endpoint
        response = self.app.post('/llm-classify', json={'text': 'Hello!'})

        # Check the response
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json['classification'], 'Hello! I\'m here to help.')

    def test_classify_no_text(self):
        # Make a POST request with no text
        response = self.app.post('/llm-classify', json={})

        # Check the response
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json['error'], 'No text provided')

    @patch('requests.post')
    def test_classify_api_error(self, mock_post):
        # Mock the API response with an error
        mock_post.side_effect = requests.RequestException("API error")

        # Make a POST request
        response = self.app.post('/llm-classify', json={'text': 'Hello!'})

        # Check the response
        self.assertEqual(response.status_code, 500)
        self.assertEqual(response.json['error'], 'API error')

if __name__ == '__main__':
    unittest.main()
