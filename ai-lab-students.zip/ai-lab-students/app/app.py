import re
from flask import Flask, request, jsonify
import logging
from flasgger import Swagger, swag_from
from sklearn.metrics import accuracy_score, precision_score, recall_score
from sklearn.exceptions import UndefinedMetricWarning
from llm_service import LLMService
from api_response_formatter import APIResponseFormatter
import warnings
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
from prometheus_client import Counter, Summary, make_wsgi_app
from werkzeug.middleware.dispatcher import DispatcherMiddleware
import pandas as pd

# Suppress specific warnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UndefinedMetricWarning)

# Prepare lists to store true and predicted labels
true_labels = []
predicted_labels = []

app = Flask(__name__)

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Initialize Swagger
swagger = Swagger(app)

# Load the CSV file into a DataFrame
df = pd.read_csv('youtoxic_english_1000.csv')

# Dependency injection of the LLM service
llm_service = LLMService(api_key="group4_vmnmu", api_url="https://llm-api.aieng.fim.uni-passau.de/v1/chat/completions")

# Prometheus metrics
REQUEST_COUNT = Counter('request_count', 'Total request count', ['method', 'endpoint'])
REQUEST_LATENCY = Summary('request_latency_seconds', 'Request latency in seconds', ['method', 'endpoint'])
ERROR_COUNT = Counter('error_count', 'Total error count', ['method', 'endpoint'])

# Expose metrics via /metrics endpoint
app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {
    '/metrics': make_wsgi_app()
})

@app.route('/llm-classify', methods=['POST'])
@swag_from({
    'summary': 'Classify user input using LLM',
    'description': 'This endpoint sends user input text to an external LLM service for classification.',
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'text': {
                        'type': 'string',
                        'description': 'Text provided by the user for classification',
                        'example': 'What is the weather like today?'
                    }
                },
                'required': ['text']
            }
        }
    ],
    'responses': {
        200: {
            'description': 'Classification result from the LLM',
            'schema': {
                'type': 'object',
                'properties': {
                    'classification': {
                        'type': 'string',
                        'description': 'The classification result',
                        'example': 'The weather today is sunny with a chance of rain.'
                    }
                }
            }
        },
        400: {
            'description': 'Bad Request - No text provided',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'No text provided'
                    }
                }
            }
        },
        500: {
            'description': 'Internal Server Error',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'Request failed: Connection error'
                    }
                }
            }
        }
    }
})
def classify():
    REQUEST_COUNT.labels(method=request.method, endpoint=request.path).inc()
    with REQUEST_LATENCY.labels(method=request.method, endpoint=request.path).time():
        data = request.get_json()
        user_text = data.get('text', '')

        if not user_text:
            app.logger.warning('No text provided')
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': 'No text provided'}), 400

        try:
            app.logger.info('Sending request to external API')
            api_response = llm_service.get_classification(user_text)
            classification_result = APIResponseFormatter.format(api_response)

            app.logger.info('Received response from external API: %s', classification_result)
            return jsonify({'classification': classification_result})
        except Exception as e:
            app.logger.error('Request failed: %s', e)
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': str(e)}), 500

@app.route('/prompt-based-classify', methods=['POST'])
@swag_from({
    'summary': 'Prompt-based classification into predefined categories',
    'description': 'This endpoint classifies the given text into one of these categories: "hate speech," "normal," or "offensive."',
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'text': {
                        'type': 'string',
                        'description': 'Text to be classified',
                        'example': 'This is an example text.'
                    }
                },
                'required': ['text']
            }
        }
    ],
    'responses': {
        200: {
            'description': 'Classification result from the LLM',
            'schema': {
                'type': 'object',
                'properties': {
                    'classification': {
                        'type': 'string',
                        'description': 'The classification result',
                        'example': 'normal'
                    }
                }
            }
        },
        400: {
            'description': 'Bad Request - No text provided',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'No text provided'
                    }
                }
            }
        },
        500: {
            'description': 'Internal Server Error',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'Request failed: Connection error'
                    }
                }
            }
        }
    }
})
def prompt_based_classify():
    REQUEST_COUNT.labels(method=request.method, endpoint=request.path).inc()
    with REQUEST_LATENCY.labels(method=request.method, endpoint=request.path).time():
        data = request.get_json()
        user_text = data.get('text', '')

        if not user_text:
            app.logger.warning('No text provided')
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': 'No text provided'}), 400

        try:
            prompt = (
                f"Classify the following text into one of these categories: 'hate speech,' 'normal,' or 'offensive.' "
                f"Text: '{user_text}'"
            )
            app.logger.info('Sending request to external API with a custom prompt')
            api_response = llm_service.get_classification(prompt)
            classification_result = APIResponseFormatter.format(api_response)

            app.logger.info('Received response from external API: %s', classification_result)
            return jsonify({'classification': classification_result})
        except Exception as e:
            app.logger.error('Request failed: %s', e)
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': str(e)}), 500

@app.route('/few-shot-classify', methods=['POST'])
@swag_from({
    'summary': 'classification using few-shot learning',
    'description': 'This endpoint classifies the given text using few-shot learning based on provided examples.',
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'text': {
                        'type': 'string',
                        'description': 'Text to be classified',
                        'example': 'You are so annoying.'
                    }
                },
                'required': ['text']
            }
        }
    ],
    'responses': {
        200: {
            'description': 'Classification result from the LLM',
            'schema': {
                'type': 'object',
                'properties': {
                    'classification': {
                        'type': 'string',
                        'description': 'The classification result',
                        'example': 'offensive'
                    }
                }
            }
        },
        400: {
            'description': 'Bad Request - No text provided',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'No text provided'
                    }
                }
            }
        },
        500: {
            'description': 'Internal Server Error',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'Request failed: Connection error'
                    }
                }
            }
        }
    }
})
def few_shot_classify():
    REQUEST_COUNT.labels(method=request.method, endpoint=request.path).inc()
    with REQUEST_LATENCY.labels(method=request.method, endpoint=request.path).time():
        data = request.get_json()
        user_text = data.get('text', '')

        if not user_text:
            app.logger.warning('No text provided')
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': 'No text provided'}), 400

        try:
            prompt = (
                "Classify the following text into one of these categories: 'hate speech,' 'normal,' or 'offensive,' "
                "based on these examples:\n"
                "- Example 1: 'I hate you.' -> 'hate speech'\n"
                "- Example 2: 'You are so annoying.' -> 'offensive'\n"
                "- Example 3: 'Have a nice day.' -> 'normal'\n\n"
                f"Text: '{user_text}'"
            )
            app.logger.info('Sending request to external API with a few-shot learning prompt')
            api_response = llm_service.get_classification(prompt)
            classification_result = APIResponseFormatter.format(api_response)

            app.logger.info('Received response from external API: %s', classification_result)
            return jsonify({'classification': classification_result})
        except Exception as e:
            app.logger.error('Request failed: %s', e)
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': str(e)}), 500

@app.route('/llm-classify-youtube-comparison', methods=['POST'])
@swag_from({
    'summary': 'Classify text from YouTube comments and calculate evaluation metrics',
    'description': (
        'This endpoint classifies the text of YouTube comments into three categories: '
        '\'hate speech\' (0), \'normal\' (1), or \'offensive\' (2). '
        'It calculates and returns accuracy, precision, and recall based on true labels '
        'and predictions made by an LLM service.'),
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'text': {
                        'type': 'string',
                        'description': 'The text to be classified',
                    }
                }
            }
        }
    ],
    'responses': {
        '200': {
            'description': 'Successful response with accuracy, precision, and recall',
            'schema': {
                'type': 'object',
                'properties': {
                    'accuracy': {
                        'type': 'number',
                        'format': 'float',
                        'description': 'Accuracy of the classification'
                    },
                    'precision': {
                        'type': 'number',
                        'format': 'float',
                        'description': 'Precision of the classification'
                    },
                    'recall': {
                        'type': 'number',
                        'format': 'float',
                        'description': 'Recall of the classification'
                    }
                }
            }
        }
    }
})
def llm_classify_youtube_comparison():
    # Initialize lists to store true and predicted labels
    true_labels = []
    predicted_labels = []

    # Iterate over the first 200 rows of the DataFrame
    for index, row in df.head(200).iterrows():
        prompt_template = (
            "Classify the following text into one of the following categories: 'hate speech,' 'normal,' or 'offensive.'\n"
            "Return 0 if it is 'hate speech,' 1 if it is 'normal,' and 2 if it is 'offensive.'\n"
            "Please print just the number not description, following these examples:\n"
            "Example 1: 'I hate you.' -> 'hate speech' (0)\n"
            "Example 2: 'You are so annoying.' -> 'offensive' (2)\n"
            "Example 3: 'Have a nice day.' -> 'normal' (1)\n"
            "Text: '{text}'"
        )

        prompt = prompt_template.format(text=row['Text'])

        # Get the classification from the LLM service
        api_response = llm_service.get_classification(prompt)
        classification_result = APIResponseFormatter.format(api_response)
        
        # Extract the classification result from the API response
        match = re.search(r'\d+', classification_result)
        predicted_label = int(match.group())

        # Determine the true label based on the row data
        if row['IsHatespeech'] or row['IsRacist'] or row['IsSexist'] or row['IsHomophobic'] or row['IsReligiousHate']:
            true_label = 0  # hate speech
        elif row['IsToxic'] or row['IsAbusive'] or row['IsObscene'] or row['IsThreat'] or row['IsProvocative']:
            true_label = 2  # offensive
        else:
            true_label = 1  # normal

        # Append the true and predicted labels to their respective lists
        true_labels.append(true_label)
        predicted_labels.append(predicted_label)
    
    # Calculate accuracy, precision, and recall
    accuracy = accuracy_score(true_labels, predicted_labels)
    precision = precision_score(true_labels, predicted_labels, average='weighted')
    recall = recall_score(true_labels, predicted_labels, average='weighted')
    
    # Return the results as JSON
    return jsonify({
        'accuracy': round(accuracy, 4),
        'precision': round(precision, 4),
        'recall': round(recall, 4)
    })

@app.route('/bert-classify-youtube-comparison', methods=['POST'])
@swag_from({
    'summary': 'Classify text from YouTube comments and calculate evaluation metrics',
    'description': (
        'This endpoint classifies the text of YouTube comments into three categories: '
        '\'hate speech\' (0), \'normal\' (1), or \'offensive\' (2). '
        'It calculates and returns accuracy, precision, and recall based on true labels '
        'and predictions made by an LLM service.'),
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'array',
                'items': {
                    'type': 'object',
                    'properties': {
                        'Text': {
                            'type': 'string',
                            'description': 'Text to be classified',
                            'example': 'This is an example text.'
                        },
                        'IsHatespeech': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is hate speech',
                            'example': False
                        },
                        'IsRacist': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is racist',
                            'example': False
                        },
                        'IsSexist': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is sexist',
                            'example': False
                        },
                        'IsHomophobic': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is homophobic',
                            'example': False
                        },
                        'IsReligiousHate': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is religious hate',
                            'example': False
                        },
                        'IsToxic': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is toxic',
                            'example': False
                        },
                        'IsAbusive': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is abusive',
                            'example': False
                        },
                        'IsObscene': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is obscene',
                            'example': False
                        },
                        'IsThreat': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is threatening',
                            'example': False
                        },
                        'IsProvocative': {
                            'type': 'boolean',
                            'description': 'Flag indicating if the text is provocative',
                            'example': False
                        }
                    }
                }
            }
        }
    ],
    'responses': {
        '200': {
            'description': 'Successful response with accuracy, precision, and recall',
            'schema': {
                'type': 'object',
                'properties': {
                    'accuracy': {
                        'type': 'number',
                        'format': 'float',
                        'description': 'Accuracy of the classification'
                    },
                    'precision': {
                        'type': 'number',
                        'format': 'float',
                        'description': 'Precision of the classification'
                    },
                    'recall': {
                        'type': 'number',
                        'format': 'float',
                        'description': 'Recall of the classification'
                    }
                }
            }
        }
    }
})
def bert_classify_youtube_comparison():
    # Load the pre-trained tokenizer and model
    tokenizer = AutoTokenizer.from_pretrained("Hate-speech-CNERG/bert-base-uncased-hatexplain")
    model = AutoModelForSequenceClassification.from_pretrained("Hate-speech-CNERG/bert-base-uncased-hatexplain", attn_implementation="eager")

    # Retrieve data from the POST request
    data = request.get_json()
    df = pd.DataFrame(data)

    # Iterate over the first 10 rows of the DataFrame
    for index, row in df.head(10).iterrows():
        # Load the pre-trained tokenizer
        tokenizer = AutoTokenizer.from_pretrained("Hate-speech-CNERG/bert-base-uncased-hatexplain")
    
        # Load the pre-trained model with the specific argument to suppress the warning
        model = AutoModelForSequenceClassification.from_pretrained(
            "Hate-speech-CNERG/bert-base-uncased-hatexplain",
            attn_implementation="eager"
        )
    
        # Prepare the input text
        inputs = tokenizer(row['Text'], return_tensors="pt", padding=True, truncation=True)
    
        # Get predictions from the model
        with torch.no_grad():
            outputs = model(**inputs)
    
        # Get the predicted class
        logits = outputs.logits
        predicted_label = torch.argmax(logits, dim=1).item()
            
        # Determine the true label based on the row data
        if row['IsHatespeech'] or row['IsRacist'] or row['IsSexist'] or row['IsHomophobic'] or row['IsReligiousHate']:
            true_label = 0  # hate speech
        elif row['IsToxic'] or row['IsAbusive'] or row['IsObscene'] or row['IsThreat'] or row['IsProvocative']:
            true_label = 2  # offensive
        else:
            true_label = 1  # normal
    
        # Append the true and predicted labels to their respective lists
        true_labels.append(true_label)
        predicted_labels.append(predicted_label)
    
    # Calculate accuracy, precision, and recall
    accuracy = accuracy_score(true_labels, predicted_labels)
    precision = precision_score(true_labels, predicted_labels, average='weighted')
    recall = recall_score(true_labels, predicted_labels, average='weighted')

    # Return the results as a JSON response
    return jsonify({
        'accuracy': round(accuracy, 4),
        'precision': round(precision, 4),
        'recall': round(recall, 4)
    })


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
