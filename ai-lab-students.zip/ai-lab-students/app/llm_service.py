import requests

class LLMService:
    def __init__(self, api_key, api_url):
        self.api_key = api_key
        self.api_url = api_url

    def get_classification(self, user_text):
        payload = {
            "model": "Mixtral-8x7B-Instruct-v0.1",
            "messages": [
                {"role": "user", "content": user_text}
            ]
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        response = requests.post(self.api_url, json=payload, headers=headers)
        response.raise_for_status()
        return response.json()
