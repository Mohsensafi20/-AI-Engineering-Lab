from sklearn.exceptions import UndefinedMetricWarning
from llm_service import LLMService
from api_response_formatter import APIResponseFormatter
import pandas as pd
import re
from sklearn.metrics import accuracy_score, precision_score, recall_score
import warnings

# Suppress specific warnings
warnings.filterwarnings("ignore", category=UndefinedMetricWarning)

# Dependency injection of the LLM service
llm_service = LLMService(api_key="group4_vmnmu", api_url="https://llm-api.aieng.fim.uni-passau.de/v1/chat/completions")

# Load the CSV file into a DataFrame
df = pd.read_csv('youtoxic_english_1000.csv')

# Prepare lists to store true and predicted labels
true_labels = []
predicted_labels = []

# Iterate over the first 10 rows of the DataFrame
for index, row in df.head(200).iterrows():
    prompt_template = (
    "Classify the following text into one of the following categories: 'hate speech,' 'normal,' or 'offensive.'\n"
    "Return 0 if it is 'hate speech,' 1 if it is 'normal,' and 2 if it is 'offensive.'\n"
    "Please print just the number not description, following these examples:\n"
    "Example 1: 'I hate you.' -> 'hate speech' (0)\n"
    "Example 2: 'You are so annoying.' -> 'offensive' (2)\n"
    "Example 3: 'Have a nice day.' -> 'normal' (1)\n"
    "Text: '{text}'"
)

    prompt = prompt_template.format(text=row['Text'])

    # Get the classification from the LLM service
    api_response = llm_service.get_classification(prompt)
    classification_result = APIResponseFormatter.format(api_response)
    
    # Extract the classification result from the API response
    match = re.search(r'\d+', classification_result)
    predicted_label = int(match.group())

    # Determine the true label based on the row data
    if row['IsHatespeech'] or row['IsRacist'] or row['IsSexist'] or row['IsHomophobic'] or row['IsReligiousHate']:
        true_label = 0  # hate speech
    elif row['IsToxic'] or row['IsAbusive'] or row['IsObscene'] or row['IsThreat'] or row['IsProvocative']:
        true_label = 2  # offensive
    else:
        true_label = 1  # normal

    # Append the true and predicted labels to their respective lists
    true_labels.append(true_label)
    predicted_labels.append(predicted_label)

# Calculate accuracy, precision, and recall
accuracy = accuracy_score(true_labels, predicted_labels)
precision = precision_score(true_labels, predicted_labels, average='weighted')
recall = recall_score(true_labels, predicted_labels, average='weighted')

# Print the results
print(f'Accuracy: {accuracy:.4f}')
print(f'Precision: {precision:.4f}')
print(f'Recall: {recall:.4f}')
