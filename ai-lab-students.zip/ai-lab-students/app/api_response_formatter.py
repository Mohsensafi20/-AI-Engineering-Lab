class APIResponseFormatter:
    @staticmethod
    def format(api_response):
        choices = api_response.get('choices', [])
        if choices:
            return choices[0].get('message', {}).get('content', 'No content found')
        else:
            return 'No choices found'
