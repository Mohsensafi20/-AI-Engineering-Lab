from flask import Flask, request, jsonify
import logging
from flasgger import Swagger, swag_from
from llm_service import LLMService
from api_response_formatter import APIResponseFormatter
import warnings
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
from prometheus_client import Counter, Summary, make_wsgi_app
from werkzeug.middleware.dispatcher import DispatcherMiddleware

# Suppress specific warnings
warnings.filterwarnings("ignore", category=FutureWarning)

app = Flask(__name__)

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Initialize Swagger
swagger = Swagger(app)

# Dependency injection of the LLM service
llm_service = LLMService(api_key="group4_vmnmu", api_url="https://llm-api.aieng.fim.uni-passau.de/v1/chat/completions")

# Prometheus metrics
REQUEST_COUNT = Counter('request_count', 'Total request count', ['method', 'endpoint'])
REQUEST_LATENCY = Summary('request_latency_seconds', 'Request latency in seconds', ['method', 'endpoint'])
ERROR_COUNT = Counter('error_count', 'Total error count', ['method', 'endpoint'])

# Expose metrics via /metrics endpoint
app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {
    '/metrics': make_wsgi_app()
})

@app.route('/llm-classify', methods=['POST'])
@swag_from({
    'summary': 'Classify user input using LLM',
    'description': 'This endpoint sends user input text to an external LLM service for classification.',
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'text': {
                        'type': 'string',
                        'description': 'Text provided by the user for classification',
                        'example': 'What is the weather like today?'
                    }
                },
                'required': ['text']
            }
        }
    ],
    'responses': {
        200: {
            'description': 'Classification result from the LLM',
            'schema': {
                'type': 'object',
                'properties': {
                    'classification': {
                        'type': 'string',
                        'description': 'The classification result',
                        'example': 'The weather today is sunny with a chance of rain.'
                    }
                }
            }
        },
        400: {
            'description': 'Bad Request - No text provided',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'No text provided'
                    }
                }
            }
        },
        500: {
            'description': 'Internal Server Error',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'Request failed: Connection error'
                    }
                }
            }
        }
    }
})
def classify():
    REQUEST_COUNT.labels(method=request.method, endpoint=request.path).inc()
    with REQUEST_LATENCY.labels(method=request.method, endpoint=request.path).time():
        data = request.get_json()
        user_text = data.get('text', '')

        if not user_text:
            app.logger.warning('No text provided')
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': 'No text provided'}), 400

        try:
            app.logger.info('Sending request to external API')
            api_response = llm_service.get_classification(user_text)
            classification_result = APIResponseFormatter.format(api_response)

            app.logger.info('Received response from external API: %s', classification_result)
            return jsonify({'classification': classification_result})
        except Exception as e:
            app.logger.error('Request failed: %s', e)
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': str(e)}), 500


@app.route('/prompt-based-classify', methods=['POST'])
@swag_from({
    'summary': 'Prompt-based classification into predefined categories',
    'description': 'This endpoint classifies the given text into one of these categories: "hate speech," "normal," or "offensive."',
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'text': {
                        'type': 'string',
                        'description': 'Text to be classified',
                        'example': 'This is an example text.'
                    }
                },
                'required': ['text']
            }
        }
    ],
    'responses': {
        200: {
            'description': 'Classification result from the LLM',
            'schema': {
                'type': 'object',
                'properties': {
                    'classification': {
                        'type': 'string',
                        'description': 'The classification result',
                        'example': 'normal'
                    }
                }
            }
        },
        400: {
            'description': 'Bad Request - No text provided',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'No text provided'
                    }
                }
            }
        },
        500: {
            'description': 'Internal Server Error',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'Request failed: Connection error'
                    }
                }
            }
        }
    }
})
def prompt_based_classify():
    REQUEST_COUNT.labels(method=request.method, endpoint=request.path).inc()
    with REQUEST_LATENCY.labels(method=request.method, endpoint=request.path).time():
        data = request.get_json()
        user_text = data.get('text', '')

        if not user_text:
            app.logger.warning('No text provided')
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': 'No text provided'}), 400

        try:
            prompt = (
                f"Classify the following text into one of these categories: 'hate speech,' 'normal,' or 'offensive.' "
                f"Text: '{user_text}'"
            )
            app.logger.info('Sending request to external API with a custom prompt')
            api_response = llm_service.get_classification(prompt)
            classification_result = APIResponseFormatter.format(api_response)

            app.logger.info('Received response from external API: %s', classification_result)
            return jsonify({'classification': classification_result})
        except Exception as e:
            app.logger.error('Request failed: %s', e)
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': str(e)}), 500


@app.route('/logit-based-classify', methods=['POST'])
@swag_from({
    'summary': 'Logit-based classification using few-shot learning',
    'description': 'This endpoint classifies the given text using few-shot learning based on provided examples.',
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'text': {
                        'type': 'string',
                        'description': 'Text to be classified',
                        'example': 'You are so annoying.'
                    }
                },
                'required': ['text']
            }
        }
    ],
    'responses': {
        200: {
            'description': 'Classification result from the LLM',
            'schema': {
                'type': 'object',
                'properties': {
                    'classification': {
                        'type': 'string',
                        'description': 'The classification result',
                        'example': 'offensive'
                    }
                }
            }
        },
        400: {
            'description': 'Bad Request - No text provided',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'No text provided'
                    }
                }
            }
        },
        500: {
            'description': 'Internal Server Error',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'Request failed: Connection error'
                    }
                }
            }
        }
    }
})
def logit_based_classify():
    REQUEST_COUNT.labels(method=request.method, endpoint=request.path).inc()
    with REQUEST_LATENCY.labels(method=request.method, endpoint=request.path).time():
        data = request.get_json()
        user_text = data.get('text', '')

        if not user_text:
            app.logger.warning('No text provided')
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': 'No text provided'}), 400

        try:
            prompt = (
                "Classify the following text into one of these categories: 'hate speech,' 'normal,' or 'offensive,' "
                "based on these examples:\n"
                "- Example 1: 'I hate you.' -> 'hate speech'\n"
                "- Example 2: 'You are so annoying.' -> 'offensive'\n"
                "- Example 3: 'Have a nice day.' -> 'normal'\n\n"
                f"Text: '{user_text}'"
            )
            app.logger.info('Sending request to external API with a few-shot learning prompt')
            api_response = llm_service.get_classification(prompt)
            classification_result = APIResponseFormatter.format(api_response)

            app.logger.info('Received response from external API: %s', classification_result)
            return jsonify({'classification': classification_result})
        except Exception as e:
            app.logger.error('Request failed: %s', e)
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': str(e)}), 500


@app.route('/multi-classify', methods=['POST'])
@swag_from({
    'summary': 'Multi-class classification using a local model',
    'description': 'This endpoint performs multi-class classification using a local machine learning model.',
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'text': {
                        'type': 'string',
                        'description': 'Text to be classified',
                        'example': 'You are amazing!'
                    }
                },
                'required': ['text']
            }
        }
    ],
    'responses': {
        200: {
            'description': 'Classification result from the local model',
            'schema': {
                'type': 'object',
                'properties': {
                    'classification': {
                        'type': 'string',
                        'description': 'The classification result',
                        'example': 'normal'
                    }
                }
            }
        },
        400: {
            'description': 'Bad Request - No text provided',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'No text provided'
                    }
                }
            }
        },
        500: {
            'description': 'Internal Server Error',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'Request failed: Connection error'
                    }
                }
            }
        }
    }
})
def multi_classify():
    REQUEST_COUNT.labels(method=request.method, endpoint=request.path).inc()
    with REQUEST_LATENCY.labels(method=request.method, endpoint=request.path).time():
        data = request.get_json()
        user_text = data.get('text', '')

        if not user_text:
            app.logger.warning('No text provided')
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': 'No text provided'}), 400

        try:
            app.logger.info('Loading local model and tokenizer')
            tokenizer = AutoTokenizer.from_pretrained("distilbert-base-uncased")
            model = AutoModelForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=3)

            inputs = tokenizer(user_text, return_tensors="pt")
            outputs = model(**inputs)
            predicted_class = torch.argmax(outputs.logits, dim=1).item()

            classification_result = ['hate speech', 'normal', 'offensive'][predicted_class]

            app.logger.info('Local model classified text as: %s', classification_result)
            return jsonify({'classification': classification_result})
        except Exception as e:
            app.logger.error('Request failed: %s', e)
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': str(e)}), 500


@app.route('/sentiment-analysis', methods=['POST'])
@swag_from({
    'summary': 'Sentiment analysis of user input',
    'description': 'This endpoint performs sentiment analysis on the provided text.',
    'parameters': [
        {
            'name': 'body',
            'in': 'body',
            'required': True,
            'schema': {
                'type': 'object',
                'properties': {
                    'text': {
                        'type': 'string',
                        'description': 'Text to analyze',
                        'example': 'I love programming!'
                    }
                },
                'required': ['text']
            }
        }
    ],
    'responses': {
        200: {
            'description': 'Sentiment analysis result',
            'schema': {
                'type': 'object',
                'properties': {
                    'sentiment': {
                        'type': 'string',
                        'description': 'The sentiment of the text',
                        'example': 'positive'
                    }
                }
            }
        },
        400: {
            'description': 'Bad Request - No text provided',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'No text provided'
                    }
                }
            }
        },
        500: {
            'description': 'Internal Server Error',
            'schema': {
                'type': 'object',
                'properties': {
                    'error': {
                        'type': 'string',
                        'description': 'Error message',
                        'example': 'Request failed: Connection error'
                    }
                }
            }
        }
    }
})
def sentiment_analysis():
    REQUEST_COUNT.labels(method=request.method, endpoint=request.path).inc()
    with REQUEST_LATENCY.labels(method=request.method, endpoint=request.path).time():
        data = request.get_json()
        user_text = data.get('text', '')

        if not user_text:
            app.logger.warning('No text provided')
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': 'No text provided'}), 400

        try:
            prompt = (
                f"Perform sentiment analysis on the following text and classify it as 'positive,' 'neutral,' or 'negative.'\n"
                f"Text: '{user_text}'"
            )
            app.logger.info('Sending request to external API for sentiment analysis')
            api_response = llm_service.get_classification(prompt)
            sentiment_result = APIResponseFormatter.format(api_response)

            app.logger.info('Received sentiment analysis result: %s', sentiment_result)
            return jsonify({'sentiment': sentiment_result})
        except Exception as e:
            app.logger.error('Request failed: %s', e)
            ERROR_COUNT.labels(method=request.method, endpoint=request.path).inc()
            return jsonify({'error': str(e)}), 500


    

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
