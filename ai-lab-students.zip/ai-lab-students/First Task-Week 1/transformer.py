import warnings
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

# Suppress specific warnings
warnings.filterwarnings("ignore", category=FutureWarning)

def classify_text(text: str) -> str:
    # Load the pre-trained tokenizer
    tokenizer = AutoTokenizer.from_pretrained("Hate-speech-CNERG/bert-base-uncased-hatexplain")

    # Load the pre-trained model with the specific argument to suppress the warning
    model = AutoModelForSequenceClassification.from_pretrained(
        "Hate-speech-CNERG/bert-base-uncased-hatexplain", 
        attn_implementation="eager"
    )

    # Prepare the input text
    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True)

    # Get predictions from the model
    with torch.no_grad():
        outputs = model(**inputs)

    # Get the predicted class
    logits = outputs.logits
    predicted_class = torch.argmax(logits, dim=1).item()

    # Map predicted class to label
    if predicted_class == 0:
        return "hate speech"
    elif predicted_class == 1:
        return "normal"
    elif predicted_class == 2:
        return "offensive"
    else:
        return "unknown"

# Example usage
text = "hi"
result = classify_text(text)
print(result)
