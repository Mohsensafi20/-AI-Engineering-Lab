from datetime import datetime
import re
from flask import Flask, flash, request, jsonify, session, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import requests
from collections import Counter

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key_here'
db = SQLAlchemy(app)

# Database Models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    preferences = db.relationship('Preferences', backref='user', uselist=False)
    favorites = db.relationship('Story', secondary='favorites', backref='users')

class Preferences(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    favorite_theme = db.Column(db.String(100), nullable=True)
    favorite_setting = db.Column(db.String(100), nullable=True)

class Story(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    child_name = db.Column(db.String(150), nullable=False)
    friend_name = db.Column(db.String(150), nullable=False)
    theme = db.Column(db.String(150), nullable=False)
    length = db.Column(db.String(50), nullable=False)
    content = db.Column(db.Text, nullable=False)
    rating = db.Column(db.Float, nullable=True)
    feedbacks = db.relationship('Feedback', back_populates='story')

class Favorites(db.Model):
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True)
    story_id = db.Column(db.Integer, db.ForeignKey('story.id'), primary_key=True)

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    story_id = db.Column(db.Integer, db.ForeignKey('story.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    story = db.relationship('Story', back_populates='feedbacks')
    user = db.relationship('User', backref=db.backref('feedback', lazy=True))

# Initialize Database
with app.app_context():
    db.create_all()

def generate_story(child_name, friend_name, story_theme, api_url, 
                   setting=None, character_traits=None, length="medium"):
    prompt_parts = [
        f"A children's story about {child_name} and their friend {friend_name}.",
        f"The story is about {story_theme}."
    ]
    
    if setting:
        prompt_parts.append(f"The story takes place in {setting}.")
    if character_traits:
        prompt_parts.append(f"The characters have the following traits: {character_traits}.")
    
    prompt_parts.append(f"The story should be {length} in length.")
    prompt = " ".join(prompt_parts)
    
    payload = {
        "model": "Mixtral-8x7B-Instruct-v0.1",
        "messages": [{"role": "user", "content": prompt}]
    }
    
    headers = {
        "Authorization": "Bearer group4_vmnmu",
        "Content-Type": "application/json"
    }
    
    response = requests.post(api_url, json=payload, headers=headers)
    response.raise_for_status()
    
    story_content = response.json()["choices"][0]["message"]["content"]
    return story_content

def post_process_story(story_content):
    # Example post-processing to remove gender stereotypes
    # This can be expanded based on more comprehensive rules and content
    story_content = re.sub(r'\bhe\b', 'they', story_content, flags=re.IGNORECASE)
    story_content = re.sub(r'\bshe\b', 'they', story_content, flags=re.IGNORECASE)
    return story_content


def summarize_and_update_preferences(user_id):
    # Fetch the user's favorite stories
    favorite_story_ids = db.session.query(Favorites.story_id).filter(Favorites.user_id == user_id).all()
    if not favorite_story_ids:
        return

    favorite_story_ids = [story_id for (story_id,) in favorite_story_ids]
    stories = Story.query.filter(Story.id.in_(favorite_story_ids)).all()

    # Extract themes and settings
    themes = [story.theme for story in stories]
    settings = [story.setting for story in stories]

    # Count the most common themes and settings
    most_common_theme = Counter(themes).most_common(1)
    most_common_setting = Counter(settings).most_common(1)

    # Get the most common theme and setting
    favorite_theme = most_common_theme[0][0] if most_common_theme else ''
    favorite_setting = most_common_setting[0][0] if most_common_setting else ''

    # Update the user's preferences
    preferences = Preferences.query.filter_by(user_id=user_id).first()
    if preferences:
        preferences.favorite_theme = favorite_theme
        preferences.favorite_setting = favorite_setting
    else:
        preferences = Preferences(user_id=user_id, favorite_theme=favorite_theme, favorite_setting=favorite_setting)
        db.session.add(preferences)

    db.session.commit()

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'], method='pbkdf2:sha256')

        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            return redirect(url_for('dashboard'))

        return "Invalid username or password"

    return render_template('login.html')

# Define allowed lengths
ALLOWED_LENGTHS = {'short', 'medium', 'long'}

def validate_story_input(child_name, friend_name, story_theme, length):
    if not child_name or not friend_name or not story_theme:
        return False, "Child's name, friend's name, and story theme are required."
    if length and length not in ALLOWED_LENGTHS:
        return False, "Length must be one of 'short', 'medium', or 'long'."
    if not re.match(r'^[a-zA-Z0-9\s]+$', child_name) or not re.match(r'^[a-zA-Z0-9\s]+$', friend_name) or not re.match(r'^[a-zA-Z0-9\s]+$', story_theme):
        return False, "Names and theme should only contain alphanumeric characters and spaces."
    return True, ""

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user = User.query.get(session['user_id'])

    if request.method == 'POST':
        # Get story details from the form
        child_name = request.form['child_name']
        friend_name = request.form['friend_name']
        story_theme = request.form['story_theme']
        length = request.form.get('length', 'medium')

        # Validate input
        is_valid, message = validate_story_input(child_name, friend_name, story_theme, length)
        if not is_valid:
            flash(message, 'danger')
            return redirect(url_for('dashboard'))

        # Generate the story
        story_content = generate_story(child_name, friend_name, story_theme,
                                       api_url="https://llm-api.aieng.fim.uni-passau.de/v1/chat/completions",
                                       length=length)

        # Post-process the story to handle biases
        story_content = post_process_story(story_content)

        # Save the story in the database
        new_story = Story(user_id=user.id, child_name=child_name, friend_name=friend_name,
                          theme=story_theme, length=length, content=story_content)
        db.session.add(new_story)
        db.session.commit()

        return redirect(url_for('dashboard'))

    stories = Story.query.filter_by(user_id=user.id).all()
    story_feedbacks = {story.id: Feedback.query.filter_by(story_id=story.id).all() for story in stories}
    
    return render_template('dashboard.html', user=user, stories=stories, story_feedbacks=story_feedbacks)

@app.route('/rate_story/<int:story_id>', methods=['POST'])
def rate_story(story_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    story = Story.query.get_or_404(story_id)

    try:
        rating = request.form['rating']

        if rating.strip() == "":
            raise ValueError("Rating cannot be empty.")
        
        rating = float(rating)

        if not 1 <= rating <= 5:
            raise ValueError("Rating must be between 1 and 5.")

        story.rating = rating
        db.session.commit()

        flash("Rating submitted successfully!", "success")
    except ValueError as e:
        flash(f"Error: {str(e)}", "danger")
    
    return redirect(url_for('dashboard'))

@app.route('/preferences', methods=['GET', 'POST'])
def preferences():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user = User.query.get(session['user_id'])
    if request.method == 'POST':
        favorite_theme = request.form.get('favorite_theme')
        favorite_setting = request.form.get('favorite_setting')

        if user.preferences:
            # Update existing preferences
            user.preferences.favorite_theme = favorite_theme
            user.preferences.favorite_setting = favorite_setting
        else:
            # Create new preferences
            new_preferences = Preferences(
                user_id=user.id,
                favorite_theme=favorite_theme,
                favorite_setting=favorite_setting
            )
            db.session.add(new_preferences)

        db.session.commit()
        flash('Preferences updated successfully!', 'success')
        return redirect(url_for('dashboard'))

    return render_template('preferences.html', user=user)

@app.route('/add_favorite/<int:story_id>', methods=['POST'])
def add_favorite(story_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    favorite = Favorites(user_id=user_id, story_id=story_id)
    db.session.add(favorite)
    db.session.commit()
    
    flash("Story added to favorites!", "success")
    return redirect(url_for('dashboard'))

@app.route('/remove_favorite/<int:story_id>', methods=['POST'])
def remove_favorite(story_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    favorite = Favorites.query.filter_by(user_id=user_id, story_id=story_id).first()
    if favorite:
        db.session.delete(favorite)
        db.session.commit()
        flash("Story removed from favorites!", "success")

    return redirect(url_for('dashboard'))

# Example route to submit feedback
@app.route('/submit_feedback/<int:story_id>', methods=['POST'])
def submit_feedback(story_id):
    if 'user_id' not in session:
        flash('Please log in to submit feedback.')
        return redirect(url_for('login'))

    user_id = session['user_id']
    feedback_content = request.form['feedback_content']

    # Create and save feedback
    feedback = Feedback(story_id=story_id, user_id=user_id, content=feedback_content)
    db.session.add(feedback)
    db.session.commit()

    flash('Thank you for your feedback!')
    return redirect(url_for('dashboard'))

# Example route to display feedback for a story
@app.route('/story/<int:story_id>')
def view_story(story_id):
    story = Story.query.get_or_404(story_id)
    feedbacks = Feedback.query.filter_by(story_id=story_id).all()
    return render_template('story.html', story=story, feedbacks=feedbacks)

@app.route('/view_feedback')
def view_feedback():
    if 'user_id' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))

    feedback_entries = Feedback.query.order_by(Feedback.timestamp.desc()).all()
    return render_template('view_feedback.html', feedback_entries=feedback_entries)

if __name__ == "__main__":
    app.run(debug=True)
