# import requests
# import matplotlib.pyplot as plt
# import pandas as pd

# # Function to generate a story with different temperature settings
# def generate_story_with_temperature(child_name, friend_name, story_theme, api_url, temperature,
#                                     setting=None, character_traits=None, length="medium"):
#     prompt_parts = [
#         f"A children's story about {child_name} and their friend {friend_name}.",
#         f"The story is about {story_theme}."
#     ]
    
#     if setting:
#         prompt_parts.append(f"The story takes place in {setting}.")
#     if character_traits:
#         prompt_parts.append(f"The characters have the following traits: {character_traits}.")
    
#     prompt_parts.append(f"The story should be {length} in length.")
#     prompt = " ".join(prompt_parts)
    
#     payload = {
#         "model": "Mixtral-8x7B-Instruct-v0.1",
#         "messages": [{"role": "user", "content": prompt}],
#         "temperature": temperature
#     }
    
#     headers = {
#         "Authorization": "Bearer group4_vmnmu",
#         "Content-Type": "application/json"
#     }
    
#     response = requests.post(api_url, json=payload, headers=headers)
#     response.raise_for_status()
    
#     story_content = response.json()["choices"][0]["message"]["content"]
#     return story_content

# # Function to evaluate stories and generate visuals
# def evaluate_and_visualize(stories, api_url, temperatures):
#     results = []

#     for temp in temperatures:
#         for story in stories:
#             content = generate_story_with_temperature(
#                 child_name=story["child_name"],
#                 friend_name=story["friend_name"],
#                 story_theme=story["story_theme"],
#                 api_url=api_url,
#                 temperature=temp,
#                 setting=story["setting"],
#                 character_traits=story["character_traits"],
#                 length=story["length"]
#             )
            
#             results.append({
#                 "temperature": temp,
#                 "story": content
#             })
    
#     # Create DataFrame for analysis
#     df = pd.DataFrame(results)

#     # Example analysis: Count of themes or keywords 
#     # extract keywords or themes from the story content
#     df['theme_count'] = df['story'].apply(lambda x: x.lower().count('adventure'))  # Example keyword
#     theme_counts = df.groupby('temperature')['theme_count'].mean()

#     # Plotting
#     plt.figure(figsize=(10, 6))
#     theme_counts.plot(kind='bar', color='skyblue')
#     plt.title('Average Theme Count Based on Temperature')
#     plt.xlabel('Temperature')
#     plt.ylabel('Average Count')
#     plt.xticks(rotation=45)
#     plt.tight_layout()
#     plt.show()

#     # Print example stories for manual review
#     for temp in temperatures:
#         print(f"Temperature: {temp}")
#         temp_stories = df[df['temperature'] == temp]
#         for i, row in temp_stories.iterrows():
#             print(f"\nStory (Temperature {temp}):")
#             print(row['story'])
#             print("="*80)

# # Sample stories
# stories = [
#     {
#         "child_name": "Emily",
#         "friend_name": "Alex",
#         "story_theme": "Friendship",
#         "setting": "Magical Forest",
#         "character_traits": "Brave, Kind",
#         "length": "medium"
#     },
#     {
#         "child_name": "Max",
#         "friend_name": "Sam",
#         "story_theme": "Adventure",
#         "setting": "Space",
#         "character_traits": "Curious, Determined",
#         "length": "short"
#     }
# ]

# # API URL
# api_url = "https://llm-api.aieng.fim.uni-passau.de/v1/chat/completions"

# # Temperatures to test
# temperatures = [0.1, 0.5, 1.0]

# # Evaluate and visualize results
# evaluate_and_visualize(stories, api_url, temperatures)


import requests
import matplotlib.pyplot as plt
import pandas as pd

# Function to generate a story with different temperature settings
def generate_story_with_temperature(child_name, friend_name, story_theme, api_url, temperature,
                                    setting=None, character_traits=None, length="medium"):
    prompt_parts = [
        f"A children's story about {child_name} and their friend {friend_name}.",
        f"The story is about {story_theme}."
    ]
    
    if setting:
        prompt_parts.append(f"The story takes place in {setting}.")
    if character_traits:
        prompt_parts.append(f"The characters have the following traits: {character_traits}.")
    
    prompt_parts.append(f"The story should be {length} in length.")
    prompt = " ".join(prompt_parts)
    
    payload = {
        "model": "Mixtral-8x7B-Instruct-v0.1",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature
    }
    
    headers = {
        "Authorization": "Bearer group4_vmnmu",
        "Content-Type": "application/json"
    }
    
    response = requests.post(api_url, json=payload, headers=headers)
    response.raise_for_status()
    
    story_content = response.json()["choices"][0]["message"]["content"]
    return story_content

# Function to evaluate stories and generate visuals for multiple keywords
def evaluate_and_visualize(stories, api_url, temperatures, keywords):
    results = []

    for temp in temperatures:
        for story in stories:
            content = generate_story_with_temperature(
                child_name=story["child_name"],
                friend_name=story["friend_name"],
                story_theme=story["story_theme"],
                api_url=api_url,
                temperature=temp,
                setting=story["setting"],
                character_traits=story["character_traits"],
                length=story["length"]
            )
            
            story_data = {
                "temperature": temp,
                "story": content
            }
            
            # Count occurrences of each keyword
            for keyword in keywords:
                keyword_count = content.lower().count(keyword.lower())
                story_data[f'count_{keyword}'] = keyword_count
            
            results.append(story_data)
    
    # Create DataFrame for analysis
    df = pd.DataFrame(results)

    # Filter out non-numeric columns (e.g., the 'story' column) before applying mean()
    numeric_df = df.filter(like='count_')

    # Add the 'temperature' column back to group by it
    numeric_df['temperature'] = df['temperature']

    # Calculate mean counts for each keyword by temperature
    keyword_means = numeric_df.groupby('temperature').mean()
    
    # Plotting
    plt.figure(figsize=(12, 8))
    keyword_means.plot(kind='bar', color=['skyblue', 'orange', 'green', 'red', 'purple'])
    plt.title('Average Keyword Count Based on Temperature')
    plt.xlabel('Temperature')
    plt.ylabel('Average Count')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    # Print example stories for manual review
    for temp in temperatures:
        print(f"Temperature: {temp}")
        temp_stories = df[df['temperature'] == temp]
        for i, row in temp_stories.iterrows():
            print(f"\nStory (Temperature {temp}):")
            print(row['story'])
            print("="*80)

# Sample stories
stories = [
    {
        "child_name": "Emily",
        "friend_name": "Alex",
        "story_theme": "Friendship",
        "setting": "Magical Forest",
        "character_traits": "Brave, Kind",
        "length": "medium"
    },
    {
        "child_name": "Max",
        "friend_name": "Sam",
        "story_theme": "Adventure",
        "setting": "Space",
        "character_traits": "Curious, Determined",
        "length": "short"
    }
]

# API URL
api_url = "https://llm-api.aieng.fim.uni-passau.de/v1/chat/completions"

# Temperatures to test
temperatures = [0.1, 0.5, 1.0]

# Keywords to analyze
keywords = ["adventure", "friendship", "magic", "brave", "curious"]

# Evaluate and visualize results
evaluate_and_visualize(stories, api_url, temperatures, keywords)
