from flask import Flask, request, jsonify, make_response, render_template
from flask_session import Session
import uuid
import secrets
import sqlite3
import main
import vectorization

app = Flask(__name__)

app.config['SESSION_TYPE'] = 'filesystem'
app.config['SECRET_KEY'] = secrets.token_hex(16)
Session(app)

main.load()

# Initialize SQLite database
def init_db():
    conn = sqlite3.connect('queries.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS queries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            category TEXT,
            query TEXT,
            response TEXT,
            vectorization_result TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/query', methods=['POST'])
def handle_query():
    session_id = request.cookies.get('session_id') or str(uuid.uuid4())
    data = request.get_json()

    area = data.get('category')
    query = data.get('query')

    # Retrieve previous queries and responses for the session
    conn = sqlite3.connect('queries.db')
    cursor = conn.cursor()
    cursor.execute('SELECT query, response FROM queries WHERE session_id = ?', (session_id,))
    previous_queries = cursor.fetchall()
    conn.close()

    # Prepare context from previous queries and responses
    context = []
    for prev_query, prev_response in previous_queries:
        context.append(f"Previous query: {prev_query}, Previous response: {prev_response}")

    # Combine context into a single string
    context_str = "\n".join(context)

    # Store the current query in the database
    conn = sqlite3.connect('queries.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO queries (session_id, category, query) VALUES (?, ?, ?)', 
                   (session_id, area, query))
    conn.commit()
    conn.close()

    # Pass the context to vectorization.run
    if area == 'lectures':
        vectorization_result = vectorization.run(area, query, context=context_str)
    else:
        vectorization_result = 'Sorry, this area is not implemented yet!'

    # Store the response and vectorization result in the database
    conn = sqlite3.connect('queries.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE queries SET response = ?, vectorization_result = ? WHERE session_id = ? AND query = ?', 
                   (vectorization_result, vectorization_result, session_id, query))
    conn.commit()
    conn.close()

    print("Received:", data)

    response_data = {
        'session_id': session_id,
        'received_data': data,
        'message': vectorization_result
    }

    response = jsonify(response_data)
    response.set_cookie('session_id', session_id, httponly=False, secure=False)
    response.mimetype = 'application/json'

    return response

@app.route('/clean', methods=['DELETE'])
def clean_data():
    session_id = request.cookies.get('session_id')

    if not session_id:
        return jsonify({'error': 'session_id is required'}), 400

    # Delete records associated with the session_id
    conn = sqlite3.connect('queries.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM queries WHERE session_id = ?', (session_id,))
    conn.commit()
    conn.close()

    return jsonify({'message': f'Data for session_id {session_id} has been cleaned.'}), 200


if __name__ == '__main__':
    app.run(debug=False)
