import os
import PyPDF2

def extract_text_from_pdf(pdf_path, skip_pages):
    """Extract text from a PDF file, excluding the last line on each page, and skipping the first `skip_pages` pages."""
    text = ''
    with open(pdf_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        
        # Iterate over the pages, skipping the first `skip_pages` pages
        for page_num, page in enumerate(reader.pages):
            if page_num < skip_pages:
                continue
            
            # Extract text from the current page
            page_text = page.extract_text()
            if page_text:
                # Split the text into lines
                lines = page_text.splitlines()
                
                # Add all lines except the last one
                if len(lines) > 1:
                    text += '\n'.join(lines[:-1]) + '\n'
                else:
                    text += lines[0] + '\n'
                
    return text

def save_text_to_file(text, file_path):
    with open(file_path, 'w', encoding='utf-8') as output_file:
        output_file.write(text)

def load_text_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as input_file:
        return input_file.read()

def process_pdf_with_cache(pdf_path, cache_path, skip_pages):
    """Process the PDF and utilize caching for faster repeated access."""
    if os.path.exists(cache_path):
        print(f"Loaded cached text from {cache_path}")
        return load_text_from_file(cache_path)
    else:
        print(f"Processing and caching text from {pdf_path}")
        text = extract_text_from_pdf(pdf_path, skip_pages)
        save_text_to_file(text, cache_path)
        return text

def main():
    # Process the first PDF with caching
    first_pdf_text = process_pdf_with_cache(
        'module-catalogs/Modulkatalog-Master-CS.pdf',
        'data/Modulkatalog-Master-CS.txt',
        30
    )

    # Process the second PDF with caching
    second_pdf_text = process_pdf_with_cache(
        'module-catalogs/Modulkatalog-Master-AI.pdf',
        'data/Modulkatalog-Master-AI.txt',
        19
    )

    print("Done")

if __name__ == "__main__":
    main()
# 1
