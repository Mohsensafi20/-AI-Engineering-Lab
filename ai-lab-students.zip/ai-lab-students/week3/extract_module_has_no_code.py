import re
import os

def read_file(file_path):
    """Read the entire content of a file."""
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def write_to_file(file_path, content):
    """Write content to a file."""
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(content)

def extract_sections(text, patterns):
    """Extract sections from the text based on the provided patterns."""
    extracted_sections = []
    for label, pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
        if match:
            extracted_sections.append(f"{label}: {match.group(0).strip()}")
    return extracted_sections

def main():

    output_file = 'data/extract_module_has_no_code_output.txt'

    if os.path.exists(output_file):
        return

    patterns = [
        ("seminar pn 450001", r"seminar pn 450001(.*?)forschungsseminar"),
        ("forschungsseminar im schwerpunkt „algmath“ pn 451010", r"forschungsseminar(.*?)forschungsseminar im schwerpunkt „infkomm“ pn 452010"),
        ("forschungsseminar im schwerpunkt „infkomm“ pn 452010", r"forschungsseminar im schwerpunkt „infkomm“ pn 452010(.*?)forschungsseminar im schwerpunkt „it-secrel“ pn 455010"),
        ("forschungsseminar im schwerpunkt „it-secrel“ pn 455010", r"forschungsseminar im schwerpunkt „it-secrel“ pn 455010(.*?)forschungsseminar im schwerpunkt „its“ pn 454010"),
        ("forschungsseminar im schwerpunkt „its“ pn 454010", r"forschungsseminar im schwerpunkt „its“ pn 454010(.*?)forschungsseminar im schwerpunkt „progsoft“ pn 453010"),
        ("forschungsseminar im schwerpunkt „progsoft“ pn 453010", r"forschungsseminar im schwerpunkt „progsoft“ pn 453010(.*?)praktikum pn 407680"),
        ("praktikum pn 407680", r"praktikum pn 407680(.*?)präsentation der masterarbeit informatik pn 458999"),
        ("präsentation der masterarbeit informatik pn 458999", r"präsentation der masterarbeit informatik pn 458999(.*?)masterarbeit informatik pn 459900"),
        ("masterarbeit informatik pn 459900", r"masterarbeit informatik pn 459900(.*)")
    ]

    # Read the content from the file
    clean_content = read_file('data/Modulkatalog-Master-cs-clean.txt')

    # Extract the sections
    extracted_sections = extract_sections(clean_content, patterns)

    # Write all captured content to a new file
    write_to_file(output_file, '\n'.join(extracted_sections))

    print("Done")

if __name__ == "__main__":
    main()
# 4
