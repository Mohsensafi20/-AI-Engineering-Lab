import re
import os

def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def extract_modules(content):
    """Extracts modules and their descriptions from the content using regex."""
    pattern = r"modulkatalog module descriptions (\d{4,5})\s+(.*?)(?=modulkatalog module descriptions \d{4,5}|$)"
    return re.findall(pattern, content, re.IGNORECASE | re.DOTALL)

def write_to_file(file_path, data):
    with open(file_path, 'w', encoding='utf-8') as file:
        for match in data:
            file.write(f"{match[0]}: {match[1]}\n")

def process_files(input_files, output_file):
    all_modules = []
    
    for file_path in input_files:
        content = read_file(file_path)
        modules = extract_modules(content)
        all_modules.extend(modules)
    
    write_to_file(output_file, all_modules)

def main():
    input_files = ['data/Modulkatalog-Master-cs-clean.txt', 'data/Modulkatalog-Master-ai-clean.txt']
    output_file = 'data/modulkatalog-master-has-code-output.txt'
    
    if os.path.exists(output_file):
        return
    # Process the input files and generate the combined output
    process_files(input_files, output_file)
    
    print("done")

if __name__ == "__main__":
    main()
# 3
