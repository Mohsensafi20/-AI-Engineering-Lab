import pandas as pd
import re
import numpy as np
import requests
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.metrics.pairwise import cosine_similarity

def read_file(file_path):
    """Reads a file and returns its lines as a list of strings."""
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.readlines()

def preprocess_text(text):
    """Preprocesses text by converting it to lowercase and removing punctuation."""
    text = text.lower()  # Convert to lowercase
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    return text

def filter_query(query):
    """Filters out common phrases from the query."""
    phrases_to_remove = ["please find", "kindly", "could you", "can you", "would you", "find"]
    for phrase in phrases_to_remove:
        query = re.sub(r'\b' + re.escape(phrase) + r'\b', '', query, flags=re.IGNORECASE)
    query = query.strip()  # Remove any leading/trailing whitespace after filtering
    return query

def vectorize_text(data, vectorizer=None, tfidf_transformer=None):
    """Converts text data to a TF-IDF matrix."""
    if vectorizer is None:
        vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(data)

    if tfidf_transformer is None:
        tfidf_transformer = TfidfTransformer()
    X_tfidf = tfidf_transformer.fit_transform(X)
    
    return X_tfidf, vectorizer, tfidf_transformer

def preprocess_query(query, vectorizer, tfidf_transformer):
    """Preprocesses and vectorizes the user query."""
    query_filtered = filter_query(query)  # Apply the filter to remove unnecessary phrases
    query_processed = preprocess_text(query_filtered)
    query_vector = vectorizer.transform([query_processed])
    return tfidf_transformer.transform(query_vector)

def find_most_similar_module(query, df, tfidf_matrix, vectorizer, tfidf_transformer, top_n=3):
    """
    Finds the most similar module to the given query based on cosine similarity.
    Also suggests additional similar modules based on the top_n parameter.
    """
    query_tfidf = preprocess_query(query, vectorizer, tfidf_transformer)
    similarities = cosine_similarity(query_tfidf, tfidf_matrix)

    # Sort modules by similarity
    sorted_indices = np.argsort(-similarities[0])  # Sort in descending order
    top_indices = sorted_indices[:top_n]  # Get the indices of the top_n most similar modules
    top_similarities = similarities[0, top_indices]
    
    # Collect the top matching modules and their scores
    similar_modules = [(df.iloc[idx], top_similarities[i]) for i, idx in enumerate(top_indices)]
    
    return similar_modules

def load_dataset(area):
    """Loads the dataset based on the user's selected area."""
    if area == "lectures":
        file_path = 'data/parse_module_data.txt'
    elif area == "news":
        file_path = 'data/news_data.txt'  # Example file path for news
    elif area == "mensa":
        file_path = 'data/mensa_menu.txt'  # Example file path for Mensa menu
    else:
        raise ValueError("Unknown area selected.")
    
    lines = read_file(file_path)
    if area == "lectures":
        # Parse the file into module code and description using colon as the delimiter
        modules = [line.split(':', 1) for line in lines]
        df = pd.DataFrame(modules, columns=['module_code', 'module_description'])
        df['module_code'] = df['module_code'].str.strip()
        df['module_description'] = df['module_description'].str.strip()
        df['combined_text'] = df['module_code'] + " " + df['module_description']
    else:
        df = pd.DataFrame(lines, columns=['combined_text'])
        df['combined_text'] = df['combined_text'].str.strip()
    
    return df

def generate_story(api_url, payload):
    headers = {
        "Authorization": "Bearer group4_vmnmu",
        "Content-Type": "application/json"
    }
    
    response = requests.post(api_url, json=payload, headers=headers)
    response.raise_for_status()
    
    content = response.json()["choices"][0]["message"]["content"]
    return content

def run(area, query, context):

    if context.strip() == "":
        context = "You are the assistant of the students " +\
            "of the University of Passau. Here is a context on " +\
            "the information that you have. " +\
            "Just answer the questions and without saying that you have " +\
            " a context. " +\
            "Start you convestion by saying hello to the student. " +\
            "Please use the context and answer the questions based on that:\n"

    df = load_dataset(area)

    tfidf_matrix, vectorizer, tfidf_transformer = vectorize_text(
        df['combined_text']
    )

    similar_modules = find_most_similar_module(
        query, df, tfidf_matrix, vectorizer, tfidf_transformer, top_n=7
    )

    for i, (module, score) in enumerate(similar_modules):
        print(f"\nMatch {i+1}:")
        print(f"{module['combined_text']}")
        # return module['combined_text']
        print(f"Similarity Score: {score}")

    api_url = "https://llm-api.aieng.fim.uni-passau.de/v1/chat/completions"
    temperature = 0.1 # 0.5, 0.7 

    for i, (module, score) in enumerate(similar_modules):
        context += module['combined_text']

    payload = {
        "model": "Mixtral-8x7B-Instruct-v0.1",
        "messages": [
            {"role": "system", "content": context},
            {"role": "user", "content": query},
        ],
        "temperature": temperature
    }

    print(payload)

    content = generate_story(api_url, payload)
    print(content)
    return content
# 6
