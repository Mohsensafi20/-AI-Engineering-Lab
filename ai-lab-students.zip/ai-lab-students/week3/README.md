# Week 3

```shell
pip install -r requirements.txt
python app.py
```

And open http://127.0.0.1:5000/ in your browser.
