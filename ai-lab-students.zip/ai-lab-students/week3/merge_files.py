import os

def merge_files(file1_path, file2_path, output_path):
    with open(file1_path, 'r', encoding='utf-8') as file1, open(file2_path, 'r', encoding='utf-8') as file2:
        file1_contents = file1.read()
        file2_contents = file2.read()

    with open(output_path, 'w', encoding='utf-8') as output_file:
        output_file.write(file1_contents)
        output_file.write(file2_contents)

def main():
    # Paths to your files
    file1_path = 'data/modulkatalog-master-has-code-output.txt'
    file2_path = 'data/extract_module_has_no_code_output.txt'
    output_path = 'data/parse_module_data.txt'

    if os.path.exists(output_path):
        return

    merge_files(file1_path, file2_path, output_path)
    print(f'Files merged into {output_path}')


if __name__ == '__main__':
    main()
# 5
