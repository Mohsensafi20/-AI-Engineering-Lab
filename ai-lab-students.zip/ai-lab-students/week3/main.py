import pdf_extractor
import preprocess_text
import extract_module_has_code
import extract_module_has_no_code
import merge_files
import vectorization


def load():
    pdf_extractor.main()
    preprocess_text.main()
    extract_module_has_code.main()
    extract_module_has_no_code.main()
    merge_files.main()


if __name__ == '__main__':
    load()
    vectorization.main()
