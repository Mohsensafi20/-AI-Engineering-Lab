import re

def preprocess_cs_text(text):
    """Preprocess the input text by converting it to lowercase and removing certain characters."""
    return text.lower().replace('\n', ' ').replace('\r', ' ').replace('39745', '39745 ')

def preprocess_ai_text(text):
    """Preprocess the input text by converting it to lowercase and removing certain characters."""
    return text.lower().replace('\n', ' ').replace('\r', ' ').replace('39745','39745 ')


def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()

def write_file(file_path, content):
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(content)

def main():
    write_file(
        'data/Modulkatalog-Master-cs-clean.txt',
        preprocess_cs_text(read_file('data/Modulkatalog-Master-CS.txt'))
    )
    write_file(
        'data/Modulkatalog-Master-ai-clean.txt',
        preprocess_ai_text(read_file('data/Modulkatalog-Master-AI.txt'))
    )

    print("Processing complete.")

if __name__ == "__main__":
    main()
# 2
